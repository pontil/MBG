// ── Mobile nav toggle ────────────────────────────────
const menuBtn = document.getElementById('menuBtn');
const navDropdown = document.getElementById('navDropdown');

menuBtn.addEventListener('click', () => {
  navDropdown.classList.toggle('open');
});

// Close nav when a link is clicked
navDropdown.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => navDropdown.classList.remove('open'));
});

// ── Password visibility toggle ───────────────────────
function togglePassword() {
  const input = document.getElementById('passwordInput');
  const icon = document.getElementById('eyeIcon');
  if (input.type === 'password') {
    input.type = 'text';
    icon.innerHTML = `<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/>`;
  } else {
    input.type = 'password';
    icon.innerHTML = `<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>`;
  }
}

// ── Animated counters ────────────────────────────────
function animateCounter(el) {
  const target = parseInt(el.dataset.target, 10);
  const duration = 1200;
  const step = 16;
  const increment = target / (duration / step);
  let current = 0;

  const timer = setInterval(() => {
    current += increment;
    if (current >= target) {
      el.textContent = target.toLocaleString('id-ID');
      clearInterval(timer);
    } else {
      el.textContent = Math.floor(current).toLocaleString('id-ID');
    }
  }, step);
}

// Trigger counters when stats section enters viewport
const statValues = document.querySelectorAll('.stat-value[data-target]');
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      animateCounter(entry.target);
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.3 });

statValues.forEach(el => observer.observe(el));

// ── Footer nav active state ───────────────────────────
const footerLinks = document.querySelectorAll('.footer-nav-item');
footerLinks.forEach(link => {
  link.addEventListener('click', () => {
    footerLinks.forEach(l => l.classList.remove('active'));
    link.classList.add('active');
  });
});

// ── Scroll: hide/show footer nav ────────────────────
let lastScroll = 0;
const footerNav = document.querySelector('.footer-nav');
window.addEventListener('scroll', () => {
  const current = window.scrollY;
  footerNav.style.transform = current > lastScroll + 30 ? 'translateY(100%)' : 'translateY(0)';
  footerNav.style.transition = 'transform 0.3s ease';
  lastScroll = current;
});
